from django.apps import AppConfig


class InventoryshopConfig(AppConfig):
    name = 'InventoryShop'

