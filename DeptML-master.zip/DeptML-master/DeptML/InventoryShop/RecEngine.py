from .models import EmpWithItems
from .models import Employees
from .models import Inventory

#Recommender functions

#Query

#Train

#Predict

#Compare new